from django.contrib import admin
from django.urls import path

from . import views

urlpatterns = [
    path('templates/index', views.index,name='index'),
    path('templates/about us', views.about us,name='about us'),
    path('templates/blog', views.blog,name='blog'),
]

